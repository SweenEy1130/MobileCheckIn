#include "sv/sv_interface.h"
#include <stdio.h>
#include <stdlib.h>

int _file_length(FILE *f)
{
    int len;

    fseek(f, 0, SEEK_END);
    len = ftell(f);
    fseek(f, 0, SEEK_SET);
    return len;
}

char* _file_read_buf(char* fn, int *n)
{
	FILE* file = fopen(fn, "rb");
	char* p = 0;
	int len;

	if (file)
	{
        len=file_length(file);
		p = (char*) malloc(len + 1);
		len = fread(p, 1, len, file);
		if (n)
		{
			*n = len;
		}
		fclose(file);
		p[len] = 0;
	}
	return p;
}


int main(int argc,char **argv)
{
	
	 
	if(argc!=5)
	{
		printf("usage: AI_SV_API resfile wavtrain wavdetect thresh\n");
		return 0;
	}

	{
	char *sv_cfg_fn=argv[1]; // res
	char *output_adapt="test.bin"; // output
	
	char *wav_train=argv[2];
	char *wav_detect=argv[3]; //

	double th = atof(argv[4]);

	 
	int i;
	char *data;
	int len;
	int ret=0;

	/* adapt */
	SVEngine *adapt=0;
	adapt = newSVEngineAdapt(sv_cfg_fn, output_adapt, 0);
	
	//read wav data, this can be called 
	data = _file_read_buf(wav_train,&len);
	ret = writeAudioToSVEngineAdaptPass1(adapt,data+44,len-44);	
	free(data);
	 
	// train  and generate the model
	ret = writeAudioToSVEngineAdaptPass2(adapt);



	if(ret!=0)
	{
		printf("speaker adapt model failed\n");
		return 0;
	}
	 
	/* detect */
	SVEngine *detect=0;
	detect = newSVEngineDetect(sv_cfg_fn, &output_adapt, 1);
	 
	data = _file_read_buf(wav_detect,&len);
	ret = writeAudioToSVEngineDetect(detect,data+44,len-44,th);
	free(data);
	
	printf("detect result:%d\n",ret);
	 
	releaseSVEngineAdapt(adapt);
	releaseSVEngineDetect(detect);
	 

	return 0;

	}

}
